# Notifications

## Objective
Use React, Vite, and the provided starter files to create an application to display a list of notifications. The user should be able to clear individual notifications or all notifications.

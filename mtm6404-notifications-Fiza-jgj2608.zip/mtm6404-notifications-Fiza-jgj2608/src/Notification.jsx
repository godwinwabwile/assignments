// Notification.js
import React from 'react';

const Notification = ({ id, name, message, onClear }) => {
  return (
    <div className="notification">
      <h3>{name}</h3>
      <p>{message}</p>
      <button onClick={() => onClear(id)}>Clear</button>
    </div>
  );
};

export default Notification;

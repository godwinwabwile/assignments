// NotificationsList.js
import React, { useState } from 'react';
import Notification from './Notification';
import notificationsData from './notifications';

const NotificationsList = () => {
  const [notifications, setNotifications] = useState(notificationsData);

  const clearNotification = (id) => {
    const updatedNotifications = notifications.filter((notification) => notification.id !== id);
    setNotifications(updatedNotifications);
  };

  const clearAllNotifications = () => {
    setNotifications([]);
  };

  return (
    <div>
      <h2>Notifications ({notifications.length})</h2>
      {notifications.map((notification) => (
        <Notification key={notification.id} {...notification} onClear={clearNotification} />
      ))}
      <button onClick={clearAllNotifications}>Clear All</button>
    </div>
  );
};

export default NotificationsList;

export default [
  {
    "id": 1,
    "name": "Charlene Clements",
    "message": "Sunt aute mollit cupidatat nisi amet laborum et commodo ullamco incididunt velit Lorem labore."
  },
  {
    "id": 2,
    "name": "Krystal Glover",
    "message": "Id enim exercitation ex in in ut proident et ut Lorem veniam."
  },
  {
    "id": 3,
    "name": "Keller Wood",
    "message": "Laborum deserunt cillum est qui anim elit culpa ipsum anim dolor."
  },
  {
    "id": 4,
    "name": "Bates Valenzuela",
    "message": "Adipisicing consequat nisi est laborum minim aliqua id."
  },
  {
    "id": 5,
    "name": "Beverly Santana",
    "message": "Qui excepteur est laboris dolor ad officia in deserunt ipsum."
  }
]